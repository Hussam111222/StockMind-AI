const { anthropicApiKey } = require("./config");
const { fetchFinnhubNews } = require("./newsProvider");

function extractText(content) {
  return content
    .map((block) => (block.type === "text" ? block.text : ""))
    .join("")
    .trim();
}

function parseJsonLoose(text) {
  const clean = text.replace(/```json|```/g, "").trim();
  return JSON.parse(clean);
}

async function callClaude({ prompt, useWebSearch }) {
  if (!anthropicApiKey) {
    throw new Error("ANTHROPIC_API_KEY is not set — add it to .env before running a refresh");
  }
  const body = {
    model: "claude-sonnet-4-6",
    max_tokens: 1000,
    messages: [{ role: "user", content: prompt }],
  };
  if (useWebSearch) {
    body.tools = [{ type: "web_search_20250305", name: "web_search" }];
  }

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": anthropicApiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Anthropic API error ${res.status}: ${errText}`);
  }
  const data = await res.json();
  return extractText(data.content);
}

// Real news, either from a dedicated financial news API (preferred, structured, reliable)
// or live web search (fallback when no news API key is configured or it returns nothing).
async function analyzeNews(ticker, name, sector) {
  let structured = null;
  try {
    structured = await fetchFinnhubNews(ticker);
  } catch (err) {
    console.error(`[aiAnalyzer] Finnhub news fetch failed for ${ticker}, falling back to web search:`, err.message);
  }

  const useWebSearch = !structured || structured.length === 0;

  const sourceBlock = useWebSearch
    ? `No structured news feed is configured (or it returned nothing) — search the web for the most recent news (last 24-48 hours) about ${ticker}.`
    : `Here is real, structured recent news pulled from a financial news API — base your analysis ONLY on this data, do not search the web:\n${structured
        .map((n, i) => `${i + 1}. [${n.source}] ${n.headline} — ${n.summary || ""}`)
        .join("\n")}`;

  const prompt = `You are analyzing recent news for ${ticker} (${name}, ${sector} sector) stock.
${sourceBlock}

Then respond with ONLY raw JSON, no markdown fences, no preamble, matching exactly this shape:
{
  "newsSentiment": "Positive" | "Negative" | "Mixed" | "Quiet",
  "summary": "<one or two plain-language sentences synthesizing what the recent news means for the stock>",
  "headlines": [
    {"title": "<short headline paraphrase, not a verbatim quote>", "source": "<publication name>", "note": "<one short sentence on why it matters>"}
  ]
}
Include up to 5 headlines. If you find little to no recent news, set newsSentiment to "Quiet" and return an empty headlines array.`;

  const text = await callClaude({ prompt, useWebSearch });
  return parseJsonLoose(text);
}

// Data-grounded narrative read for a personal watchlist tool. States a clear read (why the
// data leans toward a buy candidate or toward caution) while staying honest that it's a
// same-day read of available data/news, not a guarantee of future performance.
async function analyzeTechnicals(snapshot) {
  const stance = snapshot.classification === "rising" ? "buy candidate" : snapshot.classification === "caution" ? "one to avoid for now" : "neutral / mixed";
  const ml = snapshot.mlPrediction || {};
  const mlLine =
    ml.sampleSize > 0
      ? `Statistical model predicts: ${ml.direction} (confidence ${ml.confidence}/100), and this model's own rolling accuracy over its last ${ml.sampleSize} predictions is ${(ml.rollingAccuracy * 100).toFixed(0)}%.`
      : `Statistical model predicts: ${ml.direction} (confidence ${ml.confidence}/100). Not enough history yet to report a rolling accuracy.`;

  const prompt = `You are a personal research assistant inside a single-user stock-watchlist tool. Analyze this data snapshot and explain clearly WHY the data currently reads as a "${stance}". Be direct and specific about the reasoning, but stay honest: this is a same-day read of technicals + news + a simple statistical model, not a guarantee, so don't claim certainty about future price moves. If the statistical model's rolling accuracy is low or close to 50%, say so plainly instead of oversell it.

Ticker: ${snapshot.ticker} (${snapshot.name}, ${snapshot.sector})
Last close: ${snapshot.last}
RSI(14): ${snapshot.rsi.toFixed(1)}
SMA50: ${snapshot.sma50 ? snapshot.sma50.toFixed(2) : "n/a"}
SMA200: ${snapshot.sma200 ? snapshot.sma200.toFixed(2) : "n/a"}
Trend cross: ${snapshot.trendSignal}
20-day momentum: ${snapshot.momentum20.toFixed(2)}%
News sentiment: ${snapshot.newsSentiment}
News summary: ${snapshot.newsSummary}
${mlLine}
Composite classification: ${snapshot.classification}

Respond with ONLY raw JSON, no markdown fences, no preamble:
{
  "summary": "<two to three sentences stating clearly why this reads as a ${stance} today, referencing the specific numbers above including the statistical model's read>",
  "factors": [
    {"label": "Momentum", "note": "<one specific sentence, cite the actual number>"},
    {"label": "Trend", "note": "<one specific sentence, cite SMA/RSI>"},
    {"label": "Statistical model", "note": "<one specific sentence on the model's prediction and its own track record>"},
    {"label": "News & risk", "note": "<one specific sentence>"}
  ]
}`;

  const text = await callClaude({ prompt, useWebSearch: false });
  return parseJsonLoose(text);
}

module.exports = { analyzeNews, analyzeTechnicals };
